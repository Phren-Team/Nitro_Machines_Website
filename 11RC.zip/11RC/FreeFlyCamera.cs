﻿using UnityEngine;

namespace CodeUtils
{
    public class FreeFlyCamera : MonoBehaviour
    {
        [Header("Movement")]
        public float moveSpeed = 10f;
        public float sprintMultiplier = 4f;
        public float lookSensitivity = 2f;

        float rotationX;
        float rotationY;

        void Start()
        {
            Vector3 rot = transform.eulerAngles;
            rotationX = rot.y;
            rotationY = rot.x;

            Cursor.lockState = CursorLockMode.Locked;
        }

        void Update()
        {
            HandleMouseLook();
            HandleMovement();

            if (Input.GetKeyDown(KeyCode.Escape))
            {
                Cursor.lockState = CursorLockMode.None;
            }
        }

        void HandleMouseLook()
        {
            if (!Input.GetMouseButton(1))
                return;

            rotationX += Input.GetAxis("Mouse X") * lookSensitivity;
            rotationY -= Input.GetAxis("Mouse Y") * lookSensitivity;

            rotationY = Mathf.Clamp(rotationY, -89f, 89f);

            transform.rotation = Quaternion.Euler(rotationY, rotationX, 0f);
        }

        void HandleMovement()
        {
            float speed = moveSpeed;

            if (Input.GetKey(KeyCode.LeftShift))
                speed *= sprintMultiplier;

            Vector3 move = Vector3.zero;

            move += transform.forward * Input.GetAxisRaw("Vertical");
            move += transform.right * Input.GetAxisRaw("Horizontal");

            if (Input.GetKey(KeyCode.E))
                move += Vector3.up;

            if (Input.GetKey(KeyCode.Q))
                move += Vector3.down;

            transform.position += move.normalized * speed * Time.deltaTime;
        }
    }
}