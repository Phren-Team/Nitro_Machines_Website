using RC.Scripts.Events;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class CylinderObstacles : ObstaclesBase
{
    [SerializeField] private float _angularSpeedDegrees = 30;
    [SerializeField] private Vector3 _rotationVector;

    private Vector3 _startPosition;
    private Quaternion _startRotation;
    private bool _isReseting;

    private void OnEnable()
    {
        _startPosition = _rb.position;
        _startRotation = _rb.rotation;

        GameEventsManager.OnShowCarFinished += SetStartPosition;
    }

    private void OnDisable()
    {
        GameEventsManager.OnShowCarFinished -= SetStartPosition;
    }

    protected override void DoAction()
    {
        if (_isReseting) return;

        float rotationAmount = _angularSpeedDegrees * Time.fixedDeltaTime;
        Vector3 worldRotationAxis = _pivotPoint.TransformDirection(_rotationVector);

        Vector3 direction = _weight.position - _pivotPoint.position;
        direction = Quaternion.AngleAxis(rotationAmount, worldRotationAxis) * direction;

        Vector3 newPosition = _pivotPoint.position + direction;

        Quaternion deltaRotation = Quaternion.AngleAxis(rotationAmount, worldRotationAxis);
        Quaternion newRotation = deltaRotation * _weight.rotation;

        _rb.MovePosition(newPosition);
        _rb.MoveRotation(newRotation);
    }

    private void SetStartPosition()
    {
        StartCoroutine(Reseting());
    }

    private IEnumerator Reseting()
    {
        _isReseting = true;
        yield return new WaitForFixedUpdate();
        _rb.position = _startPosition;
        _rb.rotation = _startRotation;
        yield return new WaitForFixedUpdate();
        _isReseting = false;
    }

    private void Reset()
    {
        TryGetComponent<Rigidbody>(out _rb);
        _weight = transform;
        _pivotPoint = transform;
    }

#if UNITY_EDITOR
    protected override void OnDrawGizmosSelected()
    {
        
    }
#endif
}
