using NaughtyAttributes;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class RotatableDoorObstacle : ObstaclesBase
{
    [SerializeField] private float _angularSpeedDegrees = 30;
    [Header("Door settings")]
    [SerializeField] private DoorPresets _doorPresets;
    [SerializeField] private GameObject _door1;
    [SerializeField] private GameObject _door2;
    [SerializeField] private GameObject _door3;
    [SerializeField] private GameObject _door4;

    public enum DoorPresets
    {
        OneDoor,
        TwoDoor,
        FourDoor
    }

    private float radius;
    private float angleRad;
    private void Start()
    {
        if (_pivotPoint == null)
        {
            Debug.LogError("Pivot point �� �����!");
            enabled = false;
            return;
        }
    }
    [Button("Set door Preset")]
    private void SetPreset()
    {
        switch (_doorPresets)
        {
            case DoorPresets.OneDoor:
                _door1.SetActive(true);
                _door2.SetActive(false);
                _door3.SetActive(false);
                _door4.SetActive(false);
                break;
            case DoorPresets.TwoDoor:
                _door1.SetActive(true);
                _door2.SetActive(true);
                _door3.SetActive(false);
                _door4.SetActive(false);
                break;
            case DoorPresets.FourDoor:
                _door1.SetActive(true);
                _door2.SetActive(true);
                _door3.SetActive(true);
                _door4.SetActive(true);
                break;
        }
    }
    protected override void DoAction()
    {
        float angleDelta = _angularSpeedDegrees * Time.fixedDeltaTime;

        Quaternion deltaRotation = Quaternion.AngleAxis(angleDelta, _pivotPoint.up);

        _rb.MoveRotation(deltaRotation * _rb.rotation);
    }
#if UNITY_EDITOR
    protected override void OnDrawGizmosSelected()
    {

    }
#endif
}
