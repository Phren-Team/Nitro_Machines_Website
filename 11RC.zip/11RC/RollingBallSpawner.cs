using NaughtyAttributes;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Pool;

public class RollingBallSpawner : MonoBehaviour
{
    [SerializeField] private Transform[] _spawnPoints;
    [SerializeField] private RollingBall _ballPrefab;
    [SerializeField] private float _delayBetweenSpawn;
    [SerializeField] private float _ballLifeTime = 10;
    [MinValue(0)]
    [SerializeField] private float _startDelay = 0;

    private ObjectPool<GameObject> _pool;

    private void Start()
    {
        CreatePool();
        StartCoroutine(SpawnBall());
    }

    private void CreatePool()
    {
        _pool = new ObjectPool<GameObject>
        (
            createFunc: CreateBall,
            actionOnGet: OnTakeBall,
            actionOnRelease: OnReturnBall,
            actionOnDestroy: null,
            collectionCheck: false,
            defaultCapacity: 10,
            maxSize: 20
        );
    }

    private GameObject CreateBall()
    {
        var spawnPoint = _spawnPoints[Random.Range(0, maxExclusive: _spawnPoints.Length)];
        var barrelScript = Instantiate(_ballPrefab, spawnPoint.position, spawnPoint.rotation);
        barrelScript.SetupPool(_pool);
        return barrelScript.gameObject;
    }

    private void OnTakeBall(GameObject barrel)
    {
        var spawnPoint = _spawnPoints[Random.Range(0, maxExclusive: _spawnPoints.Length)];

        barrel.transform.SetPositionAndRotation(spawnPoint.position, spawnPoint.rotation);

        barrel.SetActive(true);

        var barrelScript = barrel.GetComponent<RollingBall>();

        barrelScript.InitParameters(_ballLifeTime);
    }

    private void OnReturnBall(GameObject barrel)
    {
        barrel.SetActive(false);
    }

    private IEnumerator SpawnBall()
    {
        yield return new WaitForSeconds(_startDelay);

        while (true)
        {
            _pool.Get();
            yield return new WaitForSeconds(_delayBetweenSpawn);
        }
        
    }
}
