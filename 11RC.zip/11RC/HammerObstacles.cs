using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class HammerObstacles : ObstaclesBase
{
    [SerializeField] private float _angularSpeedDegrees = 30;

    private float radius;
    private float angleRad;
    private float _editorAngleRad = 0f;

    private void Start()
    {
        InitLineRenderer(8);

        if (_pivotPoint == null)
        {
            Debug.LogError("Pivot point �� �����!");
            enabled = false;
            return;
        }

        radius = Vector3.Distance(_pivotPoint.position, _weight.position);

        angleRad = 0 * Mathf.Deg2Rad;
    }
    protected override void DoAction()
    {
        float angularSpeedRad = _angularSpeedDegrees * Mathf.Deg2Rad;
        angleRad += angularSpeedRad * Time.fixedDeltaTime;

        Vector3 offset = new Vector3(
            0,
            Mathf.Sin(angleRad),
            Mathf.Cos(angleRad)
        ) * radius;

        Vector3 worldOffset = transform.TransformDirection(offset);

        Vector3 targetPosition = _pivotPoint.position + worldOffset;

        _rb.MovePosition(targetPosition);

        Vector3 dir = _pivotPoint.position - _weight.position;
        Quaternion toRotation = Quaternion.LookRotation(dir);
        _rb.MoveRotation(toRotation);

        _lineRenderer.SetPosition(0, _pivotPoint.position);
        _lineRenderer.SetPosition(1, _weight.position);
    }

#if UNITY_EDITOR
    protected override void OnDrawGizmosSelected()
    {
        if (_pivotPoint == null || _weight == null || !_showGizmos) return;

        var _radius = Vector3.Distance(_pivotPoint.position, _weight.position);

        if (_lastEditorTime == 0) _lastEditorTime = EditorApplication.timeSinceStartup;
        double currentEditorTime = EditorApplication.timeSinceStartup;
        float deltaTime = (float)(currentEditorTime - _lastEditorTime);
        _lastEditorTime = currentEditorTime;

        _editorAngleRad += _angularSpeedDegrees * Mathf.Deg2Rad * deltaTime;
        if (_editorAngleRad > Mathf.PI * 2f) _editorAngleRad -= Mathf.PI * 2f;

        Vector3 axis = transform.right;

        Vector3 ortho1 = transform.up;
        Vector3 ortho2 = transform.forward;

        Vector3 circlePos = _pivotPoint.position + ortho1 * Mathf.Sin(_editorAngleRad) * _radius + ortho2 * Mathf.Cos(_editorAngleRad) * _radius;

        Gizmos.color = Color.yellow;
        Gizmos.DrawLine(_pivotPoint.position, circlePos);

        Handles.color = new Color(1f, 1f, 0f, 0.2f);
        Handles.DrawSolidDisc(_pivotPoint.position, axis, _radius);
        Handles.color = Color.yellow;
        Handles.DrawWireDisc(_pivotPoint.position, axis, _radius);
    }
#endif
}
