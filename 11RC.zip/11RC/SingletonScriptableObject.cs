using System.IO;
using UnityEditor;
using UnityEngine;

public abstract class SingletonScriptableObject<T> : ScriptableObject where T : SingletonScriptableObject<T>
{
    private static T instance;
    private static readonly string FileAssetPath = typeof(T).Name;
    private static readonly string DirectoryAssetsPath = "Assets/Resources";
    private static readonly string FileAssetFullPath = DirectoryAssetsPath + "/" + FileAssetPath + ".asset";

    public static T Instance
    {
        get
        {
            if (instance == null)
            {
                instance = Resources.Load(FileAssetPath) as T;
                if (instance == null)
                {
                    instance = Resources.Load<T>("");
                }
                
                // Если всё ещё null, можно попробовать другие варианты, например:
                if (instance == null)
                {
                    // Получаем все объекты данного типа из Resources
                    T[] allInstances = Resources.LoadAll<T>("");
                    if (allInstances != null && allInstances.Length > 0)
                    {
                        instance = allInstances[0];
                    }
                }
                if (instance == null)
                {
                    instance = CreateInstance<T>();
#if UNITY_EDITOR
                    if (!Directory.Exists(DirectoryAssetsPath))
                        Directory.CreateDirectory(DirectoryAssetsPath);

                    AssetDatabase.CreateAsset(instance, FileAssetFullPath);
                    AssetDatabase.SaveAssets();
#endif
                }

                instance.Init();
            }

            return instance;
        }
    }
    
    protected virtual void Init() { }
}