using Doozy.Runtime.Reactor.Reactions;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.Pool;

public class RollingBarrel : MonoBehaviour
{
    private Rigidbody _rb;
    private int _bounceCount;
    private int _maxBounce;
    private float _forwardSpeed = 0;
    private float _radius = 0f;
    private float _timeToDeactivate = 0f;
    private Vector3 _direction;

    private Coroutine _deactivateCoroutine;

    private IObjectPool<GameObject> _pool;

    private void Awake()
    {
        _rb = GetComponent<Rigidbody>();
    }

    public void InitParameters(int bounce, float forwardSpeed, Vector3 forwardDirection, float time)
    {
        _rb.isKinematic = false;
        _bounceCount = bounce;
        _maxBounce = bounce;
        _forwardSpeed = forwardSpeed;
        _direction = forwardDirection.normalized;
        _timeToDeactivate = time;
        _radius = GetComponent<CapsuleCollider>().radius * transform.localScale.x;
        _deactivateCoroutine = StartCoroutine(DeactivateBarrel());
    }

    public void SetupPool(ObjectPool<GameObject> pool) => _pool = pool;

    private void OnDisable()
    {
        if (_deactivateCoroutine != null)
        {
            StopCoroutine(_deactivateCoroutine);
            _deactivateCoroutine = null;
        }
        _rb.velocity = Vector3.zero;
        _rb.angularVelocity = Vector3.zero;
        _bounceCount = _maxBounce;
    }
    private IEnumerator DeactivateBarrel()
    {
        yield return new WaitForSeconds(_timeToDeactivate);

        _pool.Release(gameObject);
        _deactivateCoroutine = null;
    }
    
    private void FixedUpdate()
    {
        HandleRolling();
        HandleVisualRotating();
    }

    private void HandleRolling()
    {
        if (!isActiveAndEnabled) return;

        Vector3 horizontalVelocity = _direction.normalized * _forwardSpeed;
        _rb.velocity = new Vector3(horizontalVelocity.x, _rb.velocity.y, horizontalVelocity.z);

        if (_rb.velocity.y > 0.5f)
            _rb.velocity = new Vector3(_rb.velocity.x, 0, _rb.velocity.z);
    }

    private void HandleVisualRotating()
    {
        if (!isActiveAndEnabled) return;

        float angularSpeed = _forwardSpeed / _radius;
        float degrees = angularSpeed * Mathf.Deg2Rad * Time.fixedDeltaTime;
        transform.Rotate(transform.up, degrees, Space.Self);
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.collider.gameObject.layer == LayerMask.NameToLayer("Ground"))
        {
            if (_bounceCount > 0)
            {
                _rb.AddForce(300 * Vector3.up, ForceMode.Impulse);
                _bounceCount--;
            }
        }
    }
}
