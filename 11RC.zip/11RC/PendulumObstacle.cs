using DG.Tweening;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
public class PendulumObstacle : ObstaclesBase
{
    [Range(0, 180)]
    [SerializeField] private float _maxAngle = 45f;
    [Min(0)]
    [SerializeField] private float _gravity = 9.81f;
    [Min(0)]
    [SerializeField] private float _speedMultiplier = 2f;

    [Tooltip("Rotatable settings")]
    [SerializeField] private Transform _rotatable;
    [SerializeField] private float _rotationSpeed;

    private float _omega;
    private float _elapsedTime = 0f;
    private float _length = 5f;

    private void Start()
    {
        _length = Vector3.Distance(_pivotPoint.position, _weight.position);
        _omega = Mathf.Sqrt(_gravity / _length) * _speedMultiplier;
        _rb.isKinematic = true;
    }

    private void Update()
    {
        Vector3 localRotation = _rotatable.localEulerAngles;
        localRotation.z += _rotationSpeed * Time.deltaTime;
        _rotatable.localEulerAngles = localRotation;
    }

    protected override void DoAction()
    {
        _elapsedTime += Time.fixedDeltaTime;

        float angle = _maxAngle * Mathf.Deg2Rad * Mathf.Cos(_omega * _elapsedTime);

        Quaternion targetRotation = Quaternion.Euler(0, 0, Mathf.Rad2Deg * Mathf.Sin(angle));

        targetRotation = transform.rotation * targetRotation;

        _rb.MoveRotation(targetRotation);
    }

#if UNITY_EDITOR
    protected override void OnDrawGizmosSelected()
    {
        //if (Application.isPlaying || _pivotPoint == null || !_showGizmos)
        //    return;

        //float length = Vector3.Distance(_pivotPoint.position, _weight.position);

        //omega = Mathf.Sqrt(_gravity / length) * _speedMultiplier;

        //float simulatedTime = Time.realtimeSinceStartup;

        //float angle = _maxAngle * Mathf.Deg2Rad * Mathf.Cos(omega * simulatedTime);

        //Vector3 localOffset = new Vector3(Mathf.Sin(angle), -Mathf.Cos(angle), 0f) * length;
        //Vector3 worldOffset = transform.TransformDirection(localOffset);
        //Vector3 targetBobPosition = _pivotPoint.position + worldOffset;

        //Gizmos.color = Color.yellow;
        //Gizmos.DrawLine(_pivotPoint.position, _weight.position); 

        //Gizmos.color = Color.red;
        //Gizmos.DrawSphere(targetBobPosition, 0.15f); 

        //Gizmos.color = Color.green;
        //Gizmos.DrawLine(_pivotPoint.position, targetBobPosition);

        //Gizmos.color = Color.cyan;
        //Gizmos.DrawLine(_pivotPoint.position, _pivotPoint.position + Vector3.right * length * 0.5f);

        //Handles.color = Color.white;
        //Handles.Label(targetBobPosition + Vector3.up * 0.5f, $"Angle: {angle * Mathf.Rad2Deg:F1}�");
    }
#endif
}
