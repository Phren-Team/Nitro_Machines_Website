using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using UnityEngine;
using UnityEngine.Pool;

public class BarrelGun : MonoBehaviour
{
    [SerializeField] private RollingBarrel _barrel;
    [SerializeField] private Transform _spawnPoint;
    [SerializeField] private float _spawnDelay;

    [Header("Barrel settings")]
    [SerializeField] private float _forwardSpeed;
    [SerializeField] private float _timeToDeactivate = 3;
    [SerializeField] private int _maxBounce = 2;

    private ObjectPool<GameObject> _pool;
    private void Awake()
    {
        CreatePool();

        StartCoroutine(SpawnBarrelCoroutine());
    }

    private void CreatePool()
    {
        _pool = new ObjectPool<GameObject>
        (
            createFunc: CreateBarrel,
            actionOnGet: OnTakeBarrel,
            actionOnRelease: OnReturnBarrel,
            actionOnDestroy: null,
            collectionCheck: false,
            defaultCapacity: 10,
            maxSize: 20
        );
    }
    private IEnumerator SpawnBarrelCoroutine()
    {
        while (true)
        {
            var barrel = _pool.Get();
            yield return new WaitForSeconds(_spawnDelay);
        }
    }

    private GameObject CreateBarrel()
    {
        var barrelScript = Instantiate(_barrel, _spawnPoint.position, _spawnPoint.rotation);
        barrelScript.SetupPool(_pool);
        return barrelScript.gameObject;
    }

    private void OnTakeBarrel(GameObject barrel)
    {
        barrel.transform.SetPositionAndRotation(_spawnPoint.position, _spawnPoint.rotation);

        barrel.SetActive(true);

        var barrelScript = barrel.GetComponent<RollingBarrel>();

        barrelScript.InitParameters(_maxBounce, _forwardSpeed, transform.forward, _timeToDeactivate);

    }

    private void OnReturnBarrel(GameObject barrel)
    {
        barrel.SetActive(false);
    }
}
