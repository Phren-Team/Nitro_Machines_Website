using RC.Drift;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Pool;

[RequireComponent(typeof(Rigidbody))]
public class RollingBall : MonoBehaviour
{
    [SerializeField] private float _acceleration;
    [SerializeField] private float _gravityModifier;
    [SerializeField] private float _impactForce;
    [SerializeField] private float _lifeTime;

    private ObjectPool<GameObject> _pool;
    private Rigidbody _rb;

    private void Awake()
    {
        _rb = GetComponent<Rigidbody>();        
    }

    private void FixedUpdate()
    {
        _rb.AddForce(Physics.gravity * _gravityModifier, ForceMode.Acceleration);
    }

    public void InitParameters(float lifeTime)
    {
        _rb.angularVelocity = Vector3.zero;
        _rb.velocity = Vector3.zero;
        _lifeTime = lifeTime;
        StartCoroutine(DeactivateRoutine());
    }

    public void SetupPool(ObjectPool<GameObject> pool) => _pool = pool;

    private IEnumerator DeactivateRoutine()
    {
        yield return new WaitForSeconds(_lifeTime);
        DeactivateBall();
    }

    private void DeactivateBall()
    {
        _pool.Release(gameObject);
    }

    private void OnCollisionEnter(Collision collision)
    {
        var car = collision.gameObject.GetComponent<CarController>()
            ?? collision.gameObject.GetComponentInParent<CarController>();

        if (car != null)
        {
            float impulseStrength = _impactForce * (_rb.mass / car.Rigidbody.mass);
            car.Rigidbody.AddForce(_rb.velocity.normalized * impulseStrength, ForceMode.Impulse);
        }
    }

    private void OnDisable()
    {
        _rb.angularVelocity = Vector3.zero;
        _rb.velocity = Vector3.zero;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.layer == LayerMask.NameToLayer("KillBall"))
        {
            DeactivateBall();
        }
    }
}
