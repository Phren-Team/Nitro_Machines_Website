﻿using NaughtyAttributes;
using UnityEngine;
#if UNITY_EDITOR
using UnityEditor;
#endif

[ExecuteInEditMode]
public class LookAtWithOffset : MonoBehaviour
{
#if UNITY_EDITOR
    [Header("Target to look at"), OnValueChanged(nameof(CalculateOffsetFromCurrent))]
#endif
    public Transform target;

    [Header("Offset after rotation")]
    public Vector3 rotationOffsetEuler;

    [Tooltip("Smoothness of rotation (0 = instant, 1 = no movement)")]
    [Range(0f, 1f)] public float smoothness = 0f;

    [Tooltip("Up direction")]
    public Vector3 upDirection = Vector3.up;

    public void Update()
    {
        if (target == null) return;

        Vector3 direction = (target.position - transform.position).normalized;
        if (direction == Vector3.zero) return;

        Quaternion lookRotation = Quaternion.LookRotation(direction, upDirection);
        lookRotation *= Quaternion.Euler(rotationOffsetEuler);

        if (smoothness > 0f)
            transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, 1f - smoothness);
        else
            transform.rotation = lookRotation;
    }

#if UNITY_EDITOR
    [Button("Calculate Offset From Current Rotation")]
    private void CalculateOffsetFromCurrent()
    {
        if (target == null)
        {
            Debug.LogWarning("Target not assigned.");
            return;
        }

        Vector3 direction = (target.position - transform.position).normalized;
        if (direction == Vector3.zero)
        {
            Debug.LogWarning("Target direction is zero.");
            return;
        }

        Quaternion desiredLookRotation = Quaternion.LookRotation(direction, upDirection);
        Quaternion delta = Quaternion.Inverse(desiredLookRotation) * transform.rotation;
        rotationOffsetEuler = delta.eulerAngles;

        // Нормализация в диапазон -180..180
        rotationOffsetEuler = NormalizeEulerAngles(rotationOffsetEuler);

        Debug.Log("Offset calculated: " + rotationOffsetEuler);
    }

    private Vector3 NormalizeEulerAngles(Vector3 euler)
    {
        return new Vector3(
            NormalizeAngle(euler.x),
            NormalizeAngle(euler.y),
            NormalizeAngle(euler.z)
        );
    }

    private float NormalizeAngle(float angle)
    {
        while (angle > 180f) angle -= 360f;
        while (angle < -180f) angle += 360f;
        return angle;
    }
#endif
}
