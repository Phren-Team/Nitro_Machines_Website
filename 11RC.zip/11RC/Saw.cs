using Doozy.Runtime.UIManager.Listeners;
using Unity.Mathematics;
using UnityEngine;
using UnityEngine.Splines;

public class Saw : MonoBehaviour
{
    [SerializeField] private SplineContainer _splineContainer;
    [SerializeField] private Transform _sawObject;    
    [SerializeField] private Transform _blade;        
    [SerializeField] private Transform _startDot;        
    [SerializeField] private Transform _endDot;        
    [SerializeField] private float _movementSpeed = 1f;
    [SerializeField] private float _rotationSpeed = 360f;

    [SerializeField] private Collider _killCollider;
    [SerializeField] private Collider _defaultCollider;
    [SerializeField] private bool _isColliderActive = false;

    private float _progress = 0f;
    private bool _isForward = true;

    private void Start()
    {
        if (_killCollider != null)
            _killCollider.enabled = _isColliderActive;
        _defaultCollider.enabled = !_isColliderActive;

        _startDot.localPosition = _splineContainer.Spline.EvaluatePosition(0);
        _endDot.localPosition = _splineContainer.Spline.EvaluatePosition(1);
    }

    private void Update()
    {
        if (_splineContainer == null) return;

        float length = _splineContainer.Spline.GetLength();

        if (_isForward)
        {
            _progress += _movementSpeed * Time.deltaTime / length;
            if (_progress >= 1f)
            {
                _progress = 1f;
                _isForward = false;
            }
        }
        else
        {
            _progress -= _movementSpeed * Time.deltaTime / length;
            if (_progress <= 0f)
            {
                _progress = 0f;
                _isForward = true;
            }
        }

        var spline = _splineContainer.Spline;

        _sawObject.localPosition = spline.EvaluatePosition(_progress);
        Vector3 tangent = spline.EvaluateTangent(_progress);
        var tangentNorm = math.normalize(tangent);
        float angle = Mathf.Atan2(tangentNorm.y, tangentNorm.x) * Mathf.Rad2Deg;
        _sawObject.rotation = GetRotation();

        if (_blade != null)
        {
            _blade.Rotate(0f, _rotationSpeed * Time.deltaTime, 0, Space.Self);
        }
    }

    public Quaternion GetRotation()
    {
        Vector3 up = _splineContainer.EvaluateUpVector(_progress);
        Vector3 tangent = _splineContainer.EvaluateTangent(_progress);
        return Quaternion.LookRotation(tangent, up);
    }

}
